import { world, system } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";

system.afterEvents.scriptEventReceive.subscribe((event) => {
    const { id, sourceEntity } = event;
    if (id != "menu:timer") return;
    timer(sourceEntity);
});

function timer(player) {
    let menu = new ModalFormData();
    menu.title('Temporizador');
    menu.slider('Horas', 0, 50, 1, 0)
    menu.slider('Minutos', 0, 59, 1, 0);
    menu.slider('Segundos', 0, 59, 1, 0);
    menu.show(player).then(result => {
        if (result.canceled) return;
        timer_setter(result.formValues[0] * 3600 + result.formValues[1] * 60 + result.formValues[2]);
    })
};

function formatTime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    const formattedHours = String(hours).padStart(2, '0');
    const formattedMinutes = String(minutes).padStart(2, '0');
    const formattedSeconds = String(remainingSeconds).padStart(2, '0');
    return `${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
 }

let currentTime = formatTime(0);
let currentInterval;
function timer_setter(time) {
   if (currentInterval) {
       system.clearRun(currentInterval);
   }
   const interval = system.runInterval(() => {
       if (time <= 0) {
           system.clearRun(interval);
       } else {
           time--;
       }
       currentTime = formatTime(time)
   }, 20);
   currentInterval = interval;
};

system.runInterval(() => {
   for (const player of world.getAllPlayers()) {
       player.onScreenDisplay.setActionBar("§M" + currentTime);
   }
}, 20);